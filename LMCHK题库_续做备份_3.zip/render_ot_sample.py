#!/usr/bin/env python3
"""渲染 GEN 三层解析样板 HTML。"""
import json, html as H

def esc(s): return H.escape(str(s)) if s else ""

import re as _re
def rich(s):
    """允许 <b>/</b>,把其余裸露的 < 转义(如数学小于号 <1%)。"""
    if not s: return ""
    # 先占位保护合法标签
    s = s.replace('<b>','\x00B\x00').replace('</b>','\x00/B\x00').replace('<br>','\x00BR\x00')
    s = s.replace('<','&lt;')
    return s.replace('\x00B\x00','<b>').replace('\x00/B\x00','</b>').replace('\x00BR\x00','<br>')

data = json.loads(open('surg_ot_q_parsed.json').read())
gen = next(s for s in data if s['code'] == 'OT')
l1 = json.loads(open('ot_layer1.json').read())
l23 = json.loads(open('ot_layer23.json').read())

L1, L1_EMQ = l1['L1'], l1['L1_EMQ']
CARDS, TECHS = l23['cards'], l23['techniques']

# ─── Knowledge cards section ───
def render_card(c):
    tbl = ""
    if c.get('table'):
        t = c['table']
        head = "".join(f"<th>{esc(h)}</th>" for h in t['head'])
        rows = "".join("<tr>" + "".join(f"<td>{rich(cell)}</td>" for cell in r) + "</tr>" for r in t['rows'])
        tbl = f'<table class="kc-table"><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table>'
    parts = [f'<div class="kc-core">{rich(c["core"])}</div>', tbl]
    if c.get('mnemonic'): parts.append(f'<div class="kc-row kc-mne">{rich(c["mnemonic"])}</div>')
    if c.get('hk'): parts.append(f'<div class="kc-row kc-hk">{rich(c["hk"])}</div>')
    if c.get('trap'): parts.append(f'<div class="kc-row kc-trap">{rich(c["trap"])}</div>')
    return (f'<details class="kcard" id="kc-{c["id"]}"><summary>'
            f'<span class="kc-title">{esc(c["title"])}</span>'
            f'<span class="kc-freq">{esc(c["freq"])}</span></summary>'
            f'<div class="kc-body">{"".join(parts)}</div></details>')

cards_html = "\n".join(render_card(c) for c in CARDS)

# ─── Techniques section ───
tech_rows = "".join(
    f'<div class="tech-item"><span class="tech-name">{esc(t[0])}</span>'
    f'<span class="tech-desc">{rich(t[1])}</span></div>'
    for t in TECHS
)

# ─── Per-question ───
def render_q(q):
    if q['type'] == 'MCQ':
        key = f"MCQ{q['num']}"
        a = L1.get(key)
        opts = "".join(
            f'<li class="{"opt-ans" if a and o["letter"]==a["ans"] else ""}">'
            f'<b>{o["letter"]}.</b> {esc(o["text"])}</li>'
            for o in q['options']
        )
        ana = ""
        if a:
            card_link = ""
            if a.get('card'):
                cname = next((c['title'] for c in CARDS if c['id']==a['card']), a['card'])
                card_link = f'<a class="card-link" href="#kc-{a["card"]}">📇 关联知识卡:{esc(cname.split(" ")[0])}</a>'
            ana = (
                f'<div class="ana-head"><span class="ana-ans">{esc(a["ans"])}</span>'
                f'<span class="ana-key">🔑 {rich(a["key"])}</span></div>'
                f'<div class="ana-body">{rich(a["analysis"])}</div>'
                f'{card_link}'
            )
        return (f'<div class="q mcq"><div class="q-id">OT·{key} <span class="q-src">{esc(q["source"])}</span></div>'
                f'<div class="q-stem">{esc(q["stem"])}</div>'
                f'<ol class="q-opts">{opts}</ol>'
                f'<details class="q-ana"><summary>💡 解析</summary><div class="ana-wrap">{ana}</div></details></div>')
    else:
        key = f"EMQ{q['num']}"
        e = L1_EMQ.get(key)
        subs = "".join(f'<li><b>Q{sq["num"]}.</b> {esc(sq["text"])}</li>' for sq in q['subquestions'])
        ana = ""
        if e:
            sub_ans = "".join(f'<div class="emq-sa"><b>Q{k}.</b> {esc(v)}</div>' for k,v in e['subs'].items())
            ana = f'<div class="ana-body"><b>主题:</b>{esc(e["theme"])}<br>{sub_ans}</div>'
        emq_opts = "".join(f'<li><b>{o["letter"]}.</b> {esc(o["text"])}</li>' for o in q["options"])
        return (f'<div class="q emq"><div class="q-id">OT·{key} <span class="q-src">{esc(q["source"])}</span> · EMQ</div>'
                f'<div class="q-stem"><b>Theme:</b> {esc(q["theme"])}</div>'
                f'<ol class="q-opts emq-opts">{emq_opts}</ol>'
                f'<ol class="q-subs">{subs}</ol>'
                f'<details class="q-ana"><summary>💡 解析</summary><div class="ana-wrap">{ana}</div></details></div>')

qs_html = "\n".join(render_q(q) for q in gen['questions'])

html = f"""<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OT 骨科创伤 · 三层解析</title>
<style>
:root{{--bg:#f5f3ee;--card:#fff;--soft:#ecebe4;--ink:#1c2024;--ink2:#5a5f66;--mut:#8a8f96;
--rule:#d9d6cc;--acc:#6b2737;--acc2:#f0e0e3;--tag:#e7e5dd;
--code:"SF Mono",Menlo,Consolas,monospace;--serif:Georgia,"Songti SC",serif;
--sans:"Inter","PingFang SC","Microsoft YaHei",system-ui,sans-serif;}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font-family:var(--sans);
font-size:14.5px;line-height:1.6;max-width:1000px;margin:0 auto;padding:0 20px 80px}}
header.pg{{padding:32px 0 20px;border-bottom:2px solid var(--ink)}}
header.pg h1{{font-family:var(--serif);font-size:28px;margin:0 0 4px}}
header.pg .sub{{font-family:var(--code);font-size:12px;color:var(--mut);letter-spacing:.06em}}
h2.sec{{font-family:var(--serif);font-size:20px;margin:32px 0 12px;padding-bottom:8px;
border-bottom:1px solid var(--rule);display:flex;align-items:baseline;gap:10px}}
h2.sec .cn{{font-size:12px;color:var(--mut);font-family:var(--code)}}
/* knowledge cards */
.kcard{{background:var(--card);border:1px solid var(--rule);border-radius:6px;margin:10px 0;overflow:hidden}}
.kcard>summary{{list-style:none;cursor:pointer;padding:12px 16px;display:flex;justify-content:space-between;
align-items:center;gap:12px;background:var(--card)}}
.kcard>summary::-webkit-details-marker{{display:none}}
.kcard[open]>summary{{background:var(--acc2);border-bottom:1px solid var(--rule)}}
.kc-title{{font-weight:700;font-size:15px;color:var(--acc)}}
.kc-freq{{font-family:var(--code);font-size:11px;color:var(--mut);white-space:nowrap}}
.kc-body{{padding:14px 18px}}.kc-core{{margin-bottom:12px;line-height:1.7}}
.kc-table{{width:100%;border-collapse:collapse;margin:10px 0;font-size:13px}}
.kc-table th,.kc-table td{{border:1px solid var(--rule);padding:6px 9px;text-align:left;vertical-align:top}}
.kc-table th{{background:var(--soft);font-weight:600}}
.kc-table td:first-child{{font-weight:600;color:var(--ink2);white-space:nowrap}}
.kc-row{{margin:10px 0;padding:9px 13px;border-radius:0 5px 5px 0;font-size:13.5px;line-height:1.65}}
.kc-mne{{background:#eef6ff;border-left:3px solid #3d7fd6}}
.kc-hk{{background:var(--acc2);border-left:3px solid var(--acc)}}
.kc-trap{{background:#fff8e6;border-left:3px solid #e0a800}}
/* techniques */
.tech-item{{background:var(--card);border:1px solid var(--rule);border-radius:6px;padding:11px 15px;margin:8px 0}}
.tech-name{{display:block;font-weight:700;color:var(--acc);font-size:14px;margin-bottom:3px}}
.tech-desc{{font-size:13.5px;color:var(--ink2);line-height:1.6}}
/* questions */
.q{{background:var(--card);border:1px solid var(--rule);border-radius:6px;padding:14px 16px;margin:12px 0}}
.q-id{{font-family:var(--code);font-size:12px;color:var(--acc);font-weight:600;margin-bottom:6px}}
.q-src{{color:var(--mut);font-weight:400}}
.q-stem{{font-size:14.5px;margin-bottom:10px;line-height:1.6}}
.q-opts{{list-style:none;padding:0;margin:0 0 6px}}
.q-opts li{{padding:4px 0 4px 4px;line-height:1.5}}
.q-opts li.opt-ans{{background:#e8f5e9;border-radius:4px;padding-left:8px;font-weight:500}}
.q-subs{{list-style:none;padding:0;margin:8px 0}}
.q-subs li{{padding:5px 0;border-top:1px dashed var(--rule)}}
.emq-opts li{{display:inline-block;margin-right:14px;font-size:13px;color:var(--ink2)}}
.q-ana>summary{{list-style:none;cursor:pointer;color:var(--acc);font-weight:600;font-size:13px;padding:6px 0}}
.q-ana>summary::-webkit-details-marker{{display:none}}
.ana-wrap{{padding:8px 0}}
.ana-head{{display:flex;align-items:center;gap:10px;margin-bottom:8px;flex-wrap:wrap}}
.ana-ans{{background:var(--acc);color:#fff;font-family:var(--code);font-weight:700;font-size:15px;
padding:2px 11px;border-radius:4px}}
.ana-key{{font-size:13px;color:#b8860b;font-weight:600}}
.ana-body{{font-size:13.5px;line-height:1.7;color:var(--ink)}}
.emq-sa{{padding:3px 0;font-size:13px}}
.card-link{{display:inline-block;margin-top:8px;font-size:12.5px;color:var(--acc);text-decoration:none;
border:1px solid var(--acc2);padding:3px 10px;border-radius:4px;background:var(--acc2)}}
.card-link:hover{{background:var(--acc);color:#fff}}
.intro{{background:var(--acc2);border-radius:8px;padding:16px 20px;margin:20px 0;font-size:13.5px;line-height:1.7}}
</style></head><body>
<header class="pg"><h1>OT 骨科创伤 · 三层解析</h1>
<div class="sub">ORTHOPAEDICS &amp; TRAUMATOLOGY · 102 MCQ + 16 EMQ · LMCHK Part 1</div></header>

<div class="intro"><b>骨科三层解析,建议先卡后题:</b><br>
① <b>知识卡层</b>——17 张跨题聚合卡,覆盖脊髓平面定位、上下肢周围神经、儿童跛行、骨肿瘤、骨筋膜室综合征等本科高频轴线(如『脊髓平面定位』一张覆盖 ~15 题)<br>
② <b>技巧层</b>——骨科专属应试套路(定位三步法、反向题、血关节 vs 延迟肿等)<br>
③ <b>逐题层</b>——102 MCQ + 16 EMQ 全解:答案 + 🔑解题钥匙 + 核心/干扰项辨析 + 📇跳转知识卡<br>
<b>⚠️ 数据说明:</b>原始解析中 4 道题(旧 MCQ7/8/10/13)题干在 PDF 转换时粘连到相邻题选项尾部,已在对应知识卡内并入讲解(髁上骨折血管伤、吸毒者化脓性关节炎、婴儿 DDH、骨筋膜室 6P)。</div>

<h2 class="sec">📇 高频知识卡 <span class="cn">KNOWLEDGE CARDS · 跨题聚合,点击展开</span></h2>
{cards_html}

<h2 class="sec">🎯 MCQ 应试技巧 <span class="cn">EXAM TECHNIQUES · 骨科专属套路</span></h2>
{tech_rows}

<h2 class="sec">📝 逐题解析 <span class="cn">PER-QUESTION · 点击每题「💡 解析」展开</span></h2>
{qs_html}

</body></html>"""

with open('ot_sample.html','w') as f:
    f.write(html)
print(f"Wrote ot_sample.html ({len(html)} chars)")
