#!/usr/bin/env python3
"""GEN 完整三层解析数据。第一层逐题反馈,第二层知识卡,第三层技巧。"""
import json

# ══════════════════════════════════════════════════════════════════
# 第二层:知识卡(跨题聚合高频考点)
# 每张卡:id, title, icon, questions(涉及题号), core(核心机制),
#        table(可选矩阵), mnemonic(口诀), hk(香港考量), trap(陷阱)
# ══════════════════════════════════════════════════════════════════
CARDS = [
{
  "id": "wound-healing",
  "title": "伤口愈合的影响因素 Factors Affecting Wound Healing",
  "freq": "★★★★★ 本题库 8 题(MCQ1,5,8,11,12,20,27,40)",
  "core": "伤口一期愈合 (primary intention) 四期:<b>止血 Haemostasis → 炎症 Inflammation (0–3d) → 增殖 Proliferation (3d–3wk:成纤维细胞+胶原+血管新生+肉芽) → 重塑 Remodelling (3wk–2yr,疤痕成熟)</b>。任何干扰『氧供 / 成纤维细胞功能 / 胶原合成 / 感染控制 / 张力』的因素都延迟愈合。",
  "table": {
    "head": ["类别", "具体因素", "机制"],
    "rows": [
      ["全身 Systemic", "糖尿病 DM", "高糖损害中性粒/成纤维细胞功能,微血管病变→缺氧"],
      ["", "类固醇 / Cushing's", "抑制炎症期、↓胶原合成、↓成纤维细胞"],
      ["", "营养不良 / 低白蛋白 / 缺维C / 缺精氨酸 arginine / 缺锌", "胶原合成原料不足(维C是脯氨酸羟化辅因子)"],
      ["", "黄疸 Jaundice", "胆盐抑制成纤维细胞 + 凝血障碍(维K↓)"],
      ["", "尿毒症 Uraemia", "毒性代谢物抑制修复"],
      ["", "化疗 / 放疗", "抑制快速分裂细胞(成纤维、内皮)"],
      ["", "缺氧:CHF / COPD / PVD / 吸烟", "氧是胶原羟化必需底物"],
      ["局部 Local", "感染 Infection", "<b>最重要单一因素</b>;延长炎症期、破坏组织"],
      ["", "血供差 / 血肿 / 异物(补片) / 张力过大 / 坏死组织", "缺氧、细菌灶、机械干扰"],
    ]
  },
  "mnemonic": "口诀 <b>「DIDN'T HEAL」</b>:<b>D</b>iabetes · <b>I</b>nfection(最重要)· <b>D</b>rugs(steroid/chemo)· <b>N</b>utrition↓ · <b>T</b>issue hypoxia(CHF/COPD/PVD)· <b>H</b>aematoma · <b>E</b>dges tension · <b>A</b>ge · <b>L</b>arge foreign body。",
  "hk": "🏥 香港阻塞性黄疸(胆管结石/肝癌/胰头癌)常见,术前须查凝血、给维生素 K、充分水化防肝肾综合征——黄疸病人伤口与全身风险是本地高频考点。",
  "trap": "⚠️ 常以『EXCEPT / NOT / UNLIKELY』反向出题,把一个中性项(呼吸机 ventilator、抗生素预防、连续缝合)混入真正的损害因素。<b>低白蛋白影响、但降糖药控糖反而帮助愈合</b>(MCQ20 陷阱)。",
},
{
  "id": "post-op-fever",
  "title": "术后发热 Post-operative Pyrexia(5 个 W)",
  "freq": "★★★★★ 本题库 6 题(MCQ9,28,29,37,42,43)",
  "core": "术后发热按<b>时间轴</b>定位病因,经典『5 个 W』:",
  "table": {
    "head": ["时间", "W", "病因", "要点"],
    "rows": [
      ["Day 1–2", "Wind 风", "肺不张 Atelectasis", "<b>最常见的 day1–2 发热</b>;SpO₂↓最敏感;鼓励深呼吸/咳痰"],
      ["Day 3–5", "Water 水", "尿路感染 UTI", "导尿管相关;查尿常规"],
      ["Day 3–5", "Wound 伤口", "伤口感染", "红肿热痛渗液;金黄葡菌常见"],
      ["Day 5–7", "Walking 走", "DVT / PE", "小腿肿痛;PE 可无 DVT 前驱"],
      ["Day 5–10", "-", "深部脓肿(膈下/盆腔)", "波动热;CT 找积液"],
      ["Day 7+", "Wonder drug 药", "药物热 / 输液反应 / C.diff", "排除性诊断"],
    ]
  },
  "mnemonic": "口诀 <b>「Wind-Water-Wound-Walking-Wonder drug」</b>对应 <b>1-3-5-7-天数</b>递进。",
  "hk": "🏥 Day 1–2 发热几乎默认 atelectasis,别急着开抗生素;Day 2 高热+低血压+少尿 = 吻合口漏/脓毒症(MCQ28,Hartmann 术后),需紧急处理。",
  "trap": "⚠️ 『MOST likely』要按<b>时间概率</b>选。8h 内轻度 desaturation(MCQ43)= atelectasis,不是肺炎(太早)。Day1 发热选 atelectasis 不选 DVT/UTI(时间未到)。",
},
{
  "id": "transfusion",
  "title": "输血反应 & 大量输血 Transfusion Reactions",
  "freq": "★★★★☆ 本题库 5 题(MCQ13,15,17,18,38)",
  "core": "分两块:<b>①急性输血反应</b>(最常见病因 = <b>人为错误 human error</b>,ABO 配错)· <b>②大量输血并发症</b>(定义:24h 内输血量≥全身血容量,或 4h 内输≥½)。",
  "table": {
    "head": ["大量输血并发症", "机制"],
    "rows": [
      ["<b>高</b>钾 Hyperkalaemia", "储存红细胞 K⁺ 漏出(注意:是高钾不是低钾!)"],
      ["低钙 Hypocalcaemia", "枸橼酸 citrate 螯合 Ca²⁺"],
      ["低体温 Hypothermia", "输入冷血"],
      ["凝血障碍 Coagulopathy", "稀释性血小板↓ + 凝血因子↓"],
      ["代谢性碱中毒", "枸橼酸代谢成碳酸氢盐"],
    ]
  },
  "mnemonic": "大量输血『<b>高</b>钾、<b>低</b>钙、<b>低</b>温、<b>稀</b>凝血』。急性反应病因首位永远是 <b>human error</b>。",
  "hk": "🏥 围手术期输血有<b>免疫抑制</b>作用,已证实增加<b>结肠癌 colonic carcinoma</b> 复发率(MCQ18)——这是本地反复考的『输血对哪种病有害』。",
  "trap": "⚠️ 最大陷阱:大量输血是<b>高</b>钾(hyperkalaemia)不是低钾。储存血 K⁺ 漏出。别被『输血=丢东西=低』的直觉骗。鼻衄 epistaxis 不是输血反应表现(MCQ15)。",
},
{
  "id": "shock",
  "title": "休克识别与初始处理 Shock",
  "freq": "★★★☆☆ 本题库 3 题(MCQ4,28,30)",
  "core": "创伤/术后低血压先想<b>低血容量性休克 hypovolaemic</b>。初始复苏用<b>晶体液(NS/RL)</b>而非立即输全血(需配型)。<b>尿量(&gt;0.5 mL/kg/h)</b>是最可靠的组织灌注/复苏指标。",
  "table": {
    "head": ["休克类型", "关键鉴别"],
    "rows": [
      ["低血容量 Hypovolaemic", "四肢冷、JVP低、心动过速;创伤/出血/呕吐"],
      ["心源性 Cardiogenic", "ECG异常、肺水肿、JVP高"],
      ["脓毒性 Septic", "四肢暖、发热、感染源(Hartmann术后 day2)"],
      ["过敏性 Anaphylactic", "血管性水肿、荨麻疹、喘鸣、暴露史"],
      ["梗阻性 Obstructive", "张力气胸(叩过清)、心包填塞(心音遥远)、PE"],
    ]
  },
  "mnemonic": "复苏 ABC 后,监测靠<b>尿量</b>;初始液体选<b>晶体</b>不选全血。",
  "hk": "🏥 Hartmann 术后 day2 高热+低压+少尿 = 脓毒性休克(吻合口漏/腹膜炎),不是低血容量——看情境!",
  "trap": "⚠️ 『DOES NOT involve / 最佳指标』:立即输全血不是初始复苏(要先晶体);BP/HR 会被代偿掩盖,尿量最可靠。",
},
{
  "id": "suture",
  "title": "缝线材料 Suture Materials",
  "freq": "★★★☆☆ 本题库 2 题(MCQ19,33)",
  "core": "分<b>可吸收 absorbable</b> vs <b>不可吸收 non-absorbable</b>;<b>单股 monofilament</b> vs <b>编织 braided</b>。",
  "table": {
    "head": ["可吸收", "不可吸收"],
    "rows": [
      ["Catgut 肠线(天然)", "Prolene 聚丙烯(单股)"],
      ["Dexon 聚乙醇酸", "Nylon/Polyamide 尼龙(单股)"],
      ["Vicryl 聚乳糖(编织)", "Silk 丝线(编织)"],
      ["PDS 聚二氧六环酮(单股,长效)", "Steel 钢丝"],
    ]
  },
  "mnemonic": "记不可吸收:<b>Prolene · Nylon · Silk · Steel</b>。其余(Catgut/Dexon/Vicryl/PDS)都可吸收。",
  "hk": "🏥 成人腹部手术<b>皮肤缝合</b>常用<b>尼龙 Nylon(不可吸收单股)</b>;筋膜用 PDS/loop nylon;编织线(丝线)因藏菌不用于污染伤口。",
  "trap": "⚠️ Prolene 是唯一混在可吸收清单里的『不可吸收』(MCQ19)。皮肤缝合选 Nylon 不选 Vicryl(可吸收适合深层)。",
},
{
  "id": "wound-stages",
  "title": "伤口愈合分期 & 疤痕 Wound Healing Stages",
  "freq": "★★★☆☆ 本题库 3 题(MCQ23,35,36)",
  "core": "一期愈合四期:<b>止血→炎症→增殖(含 fibroplasia 纤维增生)→重塑</b>。<b>肉芽 granulation 是二期愈合(secondary intention)特征</b>,一期愈合肉芽极少。<b>伤口收缩 wound contraction 也是二期特征</b>。",
  "mnemonic": "疤痕成熟 <b>『takes up to 2–3 years or more』</b>;婴儿疤痕<b>更好</b>(不是更差);愈合速率<b>因部位而异</b>(面部快、下肢慢)。",
  "hk": "",
  "trap": "⚠️ 一期 vs 二期:granulation / wound contraction 是<b>二期</b>标志,问一期时它们是错误选项(MCQ23,36)。『疤痕3个月成熟』错(要2–3年);『婴儿疤痕更差』错(更好)。",
},
{
  "id": "nutrition",
  "title": "外科营养 Surgical Nutrition(肠内 vs 肠外)",
  "freq": "★★★☆☆ 本题库 3 题(MCQ7,16,24)",
  "core": "『<b>肠道能用就用肠道 If the gut works, use it</b>』:肠内营养 (enteral) 优于肠外 (TPN)——维持肠黏膜屏障、少感染、便宜。TPN 经<b>中心静脉</b>给,主要风险<b>导管相关脓毒症</b>。",
  "mnemonic": "营养评估看<b>三头肌皮褶 tricipital skinfold</b>(体脂储备)+ 白蛋白 + 体重趋势。TPN 三大风险:<b>感染 · 代谢紊乱 · 导管并发症</b>。",
  "hk": "",
  "trap": "⚠️ 高流量肠外瘘 high-output fistula <b>不是</b>肠内营养(NG)指征(会增加瘘量,MCQ16)。TPN <b>不能</b>治休克、<b>不经</b>NG给、<b>非</b>所有营养不良都获益(MCQ24)。",
},
{
  "id": "misc-onco-consent",
  "title": "杂项:肿瘤标志物 · 放疗 · 知情同意 · 微创",
  "freq": "★★☆☆☆ 散见(MCQ21,22,31,32,34)",
  "core": "高频小点合集,各记一句要点。",
  "table": {
    "head": ["考点", "要点"],
    "rows": [
      ["肿瘤标志物", "<b>非</b>肿瘤特异;主要用于<b>监测治疗反应/复发</b>;CEA↑于结直肠癌复发,hCG↑于生殖细胞瘤"],
      ["放疗主力病种", "<b>鼻咽癌 NPC</b>(放疗为主);直肠癌放疗是辅助;胃癌/黑色素瘤放疗抵抗"],
      ["知情同意", "解释<b>重要/实质</b>风险即可,非每个细节;避免胁迫;可指出医生倾向;可随时撤回"],
      ["微创优势", "<b>粘连更少</b>、创伤小、恢复快;但止血更难、触觉↓、有 iatrogenic 风险"],
      ["Erbitux(cetuximab)", "单抗<b>靶向药</b>,不是传统化疗(vs Xeloda/Taxol/5-FU/Pharmorubicin)"],
    ]
  },
  "mnemonic": "放疗记<b>NPC</b>;标志物记<b>『监测复发、非特异、非诊断』</b>。",
  "hk": "🏥 鼻咽癌是华南/香港高发,放疗为一线——本地必考。",
  "trap": "⚠️ 『tumour markers are tumour-specific』永远是<b>错的</b>(非特异)。Erbitux 是靶向药不是化疗。",
},
]

# ══════════════════════════════════════════════════════════════════
# 第三层:MCQ 应试技巧(元认知,GEN 通用)
# ══════════════════════════════════════════════════════════════════
TECHNIQUES = [
  ["EXCEPT / NOT / UNLIKELY 反向题",
   "先在脑内列出该主题的『标准清单』(如伤口愈合损害因素),逐项打勾,剩下那个<b>对不上清单的中性项</b>就是答案。本题库 GEN 至少 12 题是反向题。"],
  ["MOST likely / COMMONEST 概率题",
   "不是找『可能的』,是找『<b>最可能的</b>』。按流行病学/时间轴排序(如术后发热按 day 数),选概率最高项,即使其他选项也『可能』。"],
  ["绝对化选项通常错",
   "含 <b>always / never / all / none / only</b> 的选项多半是错的(如『TPN beneficial for ALL』『markers are tumour-specific』)。医学少有绝对。"],
  ["极端数值是陷阱",
   "正常值被放大/缩小是常见干扰(尿量 2000–2500 偏高、粪便失液 300 偏高)。记牢标准值:尿 1500 / 不显失水 800–1500 / 粪 100–200 mL。"],
  ["方向反写陷阱",
   "激素/代谢方向被写反(醛固酮『保钾』错→应保钠排钾;大量输血『低钾』错→应高钾;饥饿『BMR升』错→应降)。看到方向词多留心。"],
  ["情境题看时间线索",
   "术后并发症题,<b>post-op day 数</b>是最强线索(atelectasis早、DVT/wound中、abscess晚)。先定位时间再选。"],
  ["细胞内外/局部全身分类",
   "遇分类题先归位:细胞外主阳离子=Na⁺、内=K⁺;伤口因素分局部(感染最重要)vs全身。分类清晰则秒选。"],
]

data = {"cards": CARDS, "techniques": TECHNIQUES}
with open('gen_layer23.json', 'w') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
print(f"知识卡: {len(CARDS)} 张")
print(f"技巧: {len(TECHNIQUES)} 条")
