# LMCHK 外科/骨科题库项目 — 续做说明

## 这是什么
LMCHK Part 1 外科(Surgery)与骨科创伤(O&T)题库,1298 题,16 个专科。
正在做「三层解析」:① 逐题反馈 ② 跨题知识卡 ③ 应试技巧。

## 进度
- ✅ GEN 普外总论(43 MCQ + 6 EMQ)—— 已完成三层
- ✅ CRS 结直肠外科(110 MCQ + 8 EMQ)—— 已完成三层
- ⏭️ 下一个:EGI 上消化道(128 题)
- 待做:HBP → O&T → BR, CTS, ECS, ENT, GS, NS, OPH, PS, PRS, URO, VAS

## 下次开新对话怎么接上
把这个文件夹里的文件**全部上传**给 Claude,并说一句
「继续做 LMCHK 题库三层解析,下一科是 EGI」。Claude 就能无缝续做。

---

## 文件清单

### 🔑 核心数据(必须上传 —— 重建项目的原料)
| 文件 | 作用 |
|---|---|
| `surg_ot_q_parsed.json` | **全部 1298 题的结构化题库**(所有科目题干+选项)。这是最重要的原始数据。 |
| `gen_layer1.json` | GEN 逐题解析数据 |
| `gen_layer23.json` | GEN 知识卡 + 技巧数据 |
| `crs_layer1.json` | CRS 逐题解析数据 |
| `crs_layer23.json` | CRS 知识卡 + 技巧数据 |

### 🛠️ 生成脚本(建议上传 —— 方便直接改续做)
| 文件 | 作用 |
|---|---|
| `render_gen_sample.py` | **渲染器模板**(把三层数据渲染成 HTML)。做新科目时复用它。 |
| `gen_layer1.py` / `gen_layer23.py` | GEN 数据生成脚本(可参考格式) |
| `crs_layer1_a.py` / `crs_layer1_b.py` | CRS 逐题脚本(分两批,格式参考) |
| `crs_layer23.py` | CRS 知识卡脚本(参考如何聚合高频考点) |

### 📄 成果 HTML(单独交付,平时用这些)
- `gen_sample.html` — GEN 三层解析成品
- `crs_sample.html` — CRS 三层解析成品
- `surg_ot_qbank.html` — 主题库(1298题+刷题模式,答案默认隐藏)
> 这三个在对话里单独提供,你已经能下载。

---

## 三层解析的数据结构(给下次的 Claude 看)

**Layer 1 逐题** —— 每题一个 dict:
```
"MCQ1": {
  "ans": "E",                    // 正确答案字母
  "key": "解题钥匙(一句话技巧)",
  "analysis": "核心考点+干扰项辨析(中文,术语中英对照,用<b>加粗)",
  "card": "wound-healing"        // 关联的知识卡 id,无则 None
}
EMQ: { "theme": "主题", "subs": {"1":"答案", "2":"答案"} }
```

**Layer 2 知识卡** —— CARDS 列表,每张:
```
{ "id", "title", "freq"(★评级+涉及题号), "core"(核心机制),
  "table":{"head":[...],"rows":[[...]]}(可选矩阵),
  "mnemonic"(口诀), "hk"(香港临床珍珠), "trap"(陷阱警告) }
```

**Layer 3 技巧** —— TECHNIQUES 列表,每条 `["技巧名","说明"]`

## 做新科目的步骤(给下次的 Claude)
1. 从 `surg_ot_q_parsed.json` 读该科全部题目
2. 识别跨题重复的高频考点 → 写 `<科>_layer23.py`(知识卡+技巧)
3. 逐题写 `<科>_layer1.py`(题多则分批 a/b)
4. 复用 `render_gen_sample.py` 改成 `render_<科>_sample.py`(改 code、文件名、标题)
5. 验证 HTML(0 error)→ 交付
